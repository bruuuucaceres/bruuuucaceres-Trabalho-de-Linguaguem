//package aulas;

//public class NewClass {
//40% trabalho
//60% prova
//60% rec
    //27/03 trabalho
    //17/04 prova
    //08/05 rec
    //29/05 trabalho
    //classe stringbuffer, classe wrapper, autoboxing, varargs
    //mapeamento de hibernet
    //uso de funções static 
    //jtable
    //a classe string esconde alguns problemas
    //string buffer: imudável, cadeia de caracteres declaradas como string são imutáveis
    //isto é, seus valores n mudam e sim é criado outro objeto
    //StringBuffer sb  = newStringBuffer("objeto");
    //classes wrapper 
    //java n é totalmente orientado a objeto: pq os
    //tipos primitivos unica coisa q n é orientado a objeto em java
    //classe é quando é maiúsculo ex; string
    //classe wrapper serve para fazer conversão entre os tipos 
    //todo tipo primitivo tem uma classe pra ele
    //autoboxing: pesquisar
    // a classe wrapper deve ser usado no tela bean
    //Varargs
    //mesmo nome tipos diferentes: sobrrecarga
    //usa for pra somar vários números, 
    //soma(int .. numeros)
    //{
    //for (int 1==; i < numeros.lengt i++ 
    //lengt é atributo )
    //n tem igual pq ele extrapola o  sistema
    //ajuda a eviatr o sobrecarga de metodos, faço só um varargs que mato todos os métodos
    //o último parametro de um método tem que ser o vararg (double numD, int ..numeros) //varargs
    //quem roda primeiro na tela é o construtor
    //set enabled(false); desabilita
    //habilitar (jcomponent ... comp){
    //for(i...)
    //pai em comum //todos os componentes herdam dele, do jcomponent
    //
    //textfield se transforma em jcomponent faz um habilitar só com voi habilitar (boolean valor){ //assim n precisa fazer tanto código repetido
    //depois passa um paramtro pra poder usar
    //no nível, administrador, convidado
    //}
    //}
    // //alterar habilita
    //incluir habilita
    //confirmar desabilitar
    //cancelar
    //  JOptionPane.showConfirmDialog(null, "Deseja excluir o registro?"); //joga uma telinha pra confirmar ok e cancelar
    //   JOptionPane.showConfirmDialog(null, "Deseja excluir o registro?"); //joga uma telinha pra confirmar ok e cancelar e coloca uma telinha para digitar tbm
    //classe stática que dá pra chamar nas telas e usar sem precisar fazer muito código
    //        int resp = JOptionPane.showConfirmDialog(null, "Deseja excluir o registro?",
//                "Exclusão", JOptionPane.YES_NO_OPTION); //YES_NO_OPTION é uma constante
//        //como vou saber qual clicou? 
//        if (resp == JOptionPane.YES_OPTION); 
//        else {
//            JOptionPane.showMessageDialog(null, "Exclusão cancelada");
//            
//        }
     //classes státicas: pode usar sem precisar instanciar
    // usar usuarios e ou cliente para referencia
    //terefa: habilitar e desabilitar com o util, assim como ter uma msg no excluir
//}
