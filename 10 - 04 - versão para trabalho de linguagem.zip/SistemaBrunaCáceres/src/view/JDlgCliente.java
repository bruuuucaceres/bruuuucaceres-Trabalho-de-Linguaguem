package view;

import java.awt.Color;
import tools.Util;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

public class JDlgCliente extends javax.swing.JDialog {

    boolean incluindo;
    private MaskFormatter mascaraCPF;
    private MaskFormatter mascaraDataDeNascimento;

    public JDlgCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTitle("Cadastro de Cliente");
        setLocationRelativeTo(null);
        Util.habilitar(false, jBtnCancelar, jBtnConfirmar, jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jFmtCpf, jFmtDataNascimento, jChboAtivo);
        try {
            mascaraCPF = new MaskFormatter("###.###.###-##");
            mascaraDataDeNascimento = new MaskFormatter("##/##/###");
        } catch (Exception e) {
            System.err.println("Erro na máscara");
        }
        jFmtCpf.setFormatterFactory(new DefaultFormatterFactory(mascaraCPF));
        jFmtDataNascimento.setFormatterFactory(new DefaultFormatterFactory(mascaraDataDeNascimento));
//        jFmtCpf.setEnabled(false);
//        jChboAtivo.setEnabled(false);
//        jFmtDataNascimento.setEnabled(false);
//        jBtnAlterar.setEnabled(false);
//        jBtnCancelar.setEnabled(false);
//        jBtnConfirmar.setEnabled(false);
//        jBtnExcluir.setEnabled(false);
//        jBtnIncluir.setEnabled(false);
//        jBtnPesquisar.setEnabled(false);
//        jTxtBairro.setEnabled(false);
//        jTxtTelefoneResidencial.setEnabled(false);
//        jTxtSexo.setEnabled(false);
//        jTxtRG.setEnabled(false);
//        jTxtNome.setEnabled(false);
//        jTxtIdCliente.setEnabled(false);
//        jTxtEstadoCivil.setEnabled(false);
//        jTxtEndereco.setEnabled(false);
//        jTxtEmail.setEnabled(false);
//        jTxtCidade.setEnabled(false);
//        jTxtCep.setEnabled(false);
//        jTxtCelular.setEnabled(false);

        habilitar(true, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar);

    }

    void habilitar(boolean valor, JComponent... componentes) {
        for (int i = 0; i < componentes.length; i++) {
            JComponent componente = componentes[i];
            componente.setEnabled(valor);
        }
    }

//    void desabilitar(JComponent... componentes) {
//
//        for (int i = 0; i < componentes.length; i++) {
//            JComponent componente = componentes[i];
//            componente.setEnabled(false);
//
//        }
//    }
    void limpar() {
        Util.limpar(jBtnCancelar, jBtnConfirmar, jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jChboAtivo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTxtEmail = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTxtEstadoCivil = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTxtTelefoneResidencial = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTxtCidade = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTxtCelular = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTxtBairro = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTxtSexo = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTxtIdCliente = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTxtEndereco = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jTxtRG = new javax.swing.JTextField();
        jTxtCep = new javax.swing.JTextField();
        jChboAtivo = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        jBtnIncluir = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnPesquisar = new javax.swing.JButton();
        jFmtCpf = new javax.swing.JFormattedTextField();
        jFmtDataNascimento = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Tela de Cliente");

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });

        jLabel3.setText("RG");

        jLabel4.setText("CPF");

        jLabel6.setText("E - mail");

        jTxtEmail.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEmailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEmailFocusLost(evt);
            }
        });

        jLabel7.setText("CEP");

        jLabel8.setText("Estado Civil");

        jTxtEstadoCivil.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEstadoCivilFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEstadoCivilFocusLost(evt);
            }
        });

        jLabel9.setText("Telefone Residencial");

        jTxtTelefoneResidencial.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtTelefoneResidencialFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtTelefoneResidencialFocusLost(evt);
            }
        });

        jLabel10.setText("Cidade");

        jTxtCidade.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCidadeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCidadeFocusLost(evt);
            }
        });

        jLabel11.setText("Celular");

        jTxtCelular.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCelularFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCelularFocusLost(evt);
            }
        });

        jLabel12.setText("Bairro");

        jTxtBairro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtBairroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtBairroFocusLost(evt);
            }
        });

        jLabel13.setText("Sexo");

        jLabel14.setText("Código");

        jTxtIdCliente.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtIdClienteFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtIdClienteFocusLost(evt);
            }
        });

        jLabel15.setText("Nome");

        jLabel16.setText("Endereço");

        jLabel17.setText("Data de nascimento");

        jTxtRG.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtRGFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtRGFocusLost(evt);
            }
        });

        jTxtCep.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCepFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCepFocusLost(evt);
            }
        });

        jChboAtivo.setText("Ativo");

        jPanel1.setBackground(new java.awt.Color(255, 153, 255));

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(jBtnIncluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnExcluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnAlterar)
                .addGap(10, 10, 10)
                .addComponent(jBtnCancelar)
                .addGap(18, 18, 18)
                .addComponent(jBtnConfirmar)
                .addGap(18, 18, 18)
                .addComponent(jBtnPesquisar))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnIncluir)
                    .addComponent(jBtnExcluir)
                    .addComponent(jBtnAlterar)
                    .addComponent(jBtnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtnPesquisar)
                    .addComponent(jBtnCancelar))
                .addGap(1, 1, 1))
        );

        jFmtCpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#########-##"))));
        jFmtCpf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusLost(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel9)
                            .addComponent(jTxtTelefoneResidencial, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                            .addComponent(jFmtCpf))
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel3)
                                    .addComponent(jTxtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel12)
                            .addComponent(jLabel8)
                            .addComponent(jTxtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jTxtRG, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTxtEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel14)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jFmtDataNascimento, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                                .addComponent(jLabel10)
                                .addComponent(jLabel7)
                                .addComponent(jTxtCep, javax.swing.GroupLayout.DEFAULT_SIZE, 183, Short.MAX_VALUE)
                                .addComponent(jTxtCelular)
                                .addComponent(jTxtCidade)))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel13)
                                    .addComponent(jTxtEndereco, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                                    .addComponent(jTxtSexo)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addComponent(jChboAtivo))))
                    .addComponent(jLabel11))
                .addGap(1, 1, 1))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15)
                            .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 87, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel14))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(jLabel10)))
                        .addGap(14, 14, 14))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(9, 9, 9))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(4, 4, 4)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTxtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTxtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel8)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTxtEstadoCivil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(jLabel12)
                            .addComponent(jLabel17)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTxtIdCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtRG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTxtCep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTxtTelefoneResidencial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTxtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jChboAtivo))
                            .addComponent(jLabel2))
                        .addGap(35, 35, 35))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jFmtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
//        desabilitar();
        Util.limpar(jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jFmtCpf, jFmtDataNascimento, jChboAtivo);
        habilitar(false, jTxtBairro, jFmtDataNascimento, jFmtCpf, jChboAtivo, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        Object usuarios = null;
        if (usuarios != null) {
            incluindo = false;
            habilitar(true, jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jChboAtivo, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar, jBtnCancelar, jBtnConfirmar);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum produto está disponível para alteração.");
        }
        // habilitar();
    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
//        int resp = JOptionPane.showConfirmDialog(null, "Deseja excluir o registro?",
//                "Exclusão", JOptionPane.YES_NO_OPTION); //YES_NO_OPTION é uma constante
//        //como vou saber qual clicou? 
//        if (resp == JOptionPane.YES_OPTION); 
//        else {
//            JOptionPane.showMessageDialog(null, "Exclusão cancelada");
//            
//        }
        if (Util.perguntar("Deseja excluir o registro?") == true) {
        } else {
            Util.mensagem("Exclusão cancelada");
        }
        Util.limpar(jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jFmtCpf, jFmtDataNascimento, jChboAtivo);
        //classes státicas: pode usar sem precisar instanciar

    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
        habilitar(true, jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jBtnCancelar, jBtnConfirmar, jFmtCpf, jFmtDataNascimento, jChboAtivo);
//     incluindo = true;
        habilitar(false, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        incluindo = true;
//        habilitar(true);
        Util.limpar(jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jFmtCpf, jFmtDataNascimento, jChboAtivo);
    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
//        desabilitar();
        if (incluindo == true) {
        } else {
        }
        Util.limpar(jTxtBairro, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jFmtCpf, jFmtDataNascimento, jChboAtivo);
        habilitar(false, jTxtBairro, jFmtDataNascimento, jFmtCpf, jChboAtivo, jTxtCelular, jTxtCep, jTxtCidade, jTxtEmail, jTxtEndereco, jTxtEstadoCivil, jTxtIdCliente, jTxtNome, jTxtRG, jTxtSexo, jTxtTelefoneResidencial, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar, jChboAtivo);
    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        // TODO add your handling code here:
        JDlgClientePesquisa jDlgClienteUsuario = new JDlgClientePesquisa(null, true);
        jDlgClienteUsuario.setVisible(true);
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jTxtIdClienteFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdClienteFocusGained
        // TODO add your handling code here:
        jTxtIdCliente.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtIdClienteFocusGained

    private void jTxtIdClienteFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdClienteFocusLost
        // TODO add your handling code here:
        jTxtIdCliente.setBackground(Color.white);
    }//GEN-LAST:event_jTxtIdClienteFocusLost

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jFmtCpfFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusGained
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtCpfFocusGained

    private void jFmtCpfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusLost
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.white);
    }//GEN-LAST:event_jFmtCpfFocusLost

    private void jTxtTelefoneResidencialFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneResidencialFocusGained
        // TODO add your handling code here:
        jTxtTelefoneResidencial.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtTelefoneResidencialFocusGained

    private void jTxtTelefoneResidencialFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneResidencialFocusLost
        // TODO add your handling code here:
        jTxtTelefoneResidencial.setBackground(Color.white);
    }//GEN-LAST:event_jTxtTelefoneResidencialFocusLost

    private void jTxtEmailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEmailFocusGained
        // TODO add your handling code here:
        jTxtEmail.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEmailFocusGained

    private void jTxtEmailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEmailFocusLost
        // TODO add your handling code here:
        jTxtEmail.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEmailFocusLost

    private void jTxtRGFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtRGFocusGained
        // TODO add your handling code here:
        jTxtRG.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtRGFocusGained

    private void jTxtRGFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtRGFocusLost
        // TODO add your handling code here:
        jTxtRG.setBackground(Color.white);
    }//GEN-LAST:event_jTxtRGFocusLost

    private void jTxtEstadoCivilFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstadoCivilFocusGained
        // TODO add your handling code here:
        jTxtEstadoCivil.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEstadoCivilFocusGained

    private void jTxtEstadoCivilFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstadoCivilFocusLost
        // TODO add your handling code here:
        jTxtEstadoCivil.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEstadoCivilFocusLost

    private void jTxtBairroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtBairroFocusGained
        // TODO add your handling code here:
        jTxtBairro.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtBairroFocusGained

    private void jTxtBairroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtBairroFocusLost
        // TODO add your handling code here:
        jTxtBairro.setBackground(Color.white);
    }//GEN-LAST:event_jTxtBairroFocusLost

    private void jTxtCidadeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCidadeFocusGained
        // TODO add your handling code here:
        jTxtCidade.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCidadeFocusGained

    private void jTxtCidadeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCidadeFocusLost
        // TODO add your handling code here:
        jTxtCidade.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCidadeFocusLost

    private void jTxtCepFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCepFocusGained
        // TODO add your handling code here:
        jTxtCep.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCepFocusGained

    private void jTxtCepFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCepFocusLost
        // TODO add your handling code here:
        jTxtCep.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCepFocusLost

    private void jTxtCelularFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCelularFocusGained
        // TODO add your handling code here:
        jTxtCelular.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCelularFocusGained

    private void jTxtCelularFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCelularFocusLost
        // TODO add your handling code here:
        jTxtCelular.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCelularFocusLost

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgCliente dialog = null;
                dialog = new JDlgCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JCheckBox jChboAtivo;
    private javax.swing.JFormattedTextField jFmtCpf;
    private javax.swing.JFormattedTextField jFmtDataNascimento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTxtBairro;
    private javax.swing.JTextField jTxtCelular;
    private javax.swing.JTextField jTxtCep;
    private javax.swing.JTextField jTxtCidade;
    private javax.swing.JTextField jTxtEmail;
    private javax.swing.JFormattedTextField jTxtEndereco;
    private javax.swing.JTextField jTxtEstadoCivil;
    private javax.swing.JTextField jTxtIdCliente;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtRG;
    private javax.swing.JTextField jTxtSexo;
    private javax.swing.JTextField jTxtTelefoneResidencial;
    // End of variables declaration//GEN-END:variables

}
