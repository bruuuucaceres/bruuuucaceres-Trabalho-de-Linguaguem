package view;

import java.awt.Color;
import javax.swing.JComponent;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.swing.JComponent;
//import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import tools.Util;

public class JDlgUsuarios extends javax.swing.JDialog {

    boolean incluindo;
    private MaskFormatter mascaraCPF;
    private MaskFormatter mascaraDataDeNascimento;

    public JDlgUsuarios(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTitle("Cadastro do Usuário");
        setLocationRelativeTo(null);
        Util.habilitar(false, jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jBtnCancelar, jBtnConfirmar, jChbAtivo);
        Util.habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        try {
            mascaraCPF = new MaskFormatter("###.###.###-##");
            mascaraDataDeNascimento = new MaskFormatter("##/##/###");
        } catch (Exception e) {
            System.err.println("Erro na máscara");
        }
        jFmtCpf.setFormatterFactory(new DefaultFormatterFactory(mascaraCPF));
        jFmtDataNascimento.setFormatterFactory(new DefaultFormatterFactory(mascaraDataDeNascimento));
//        habilitar(false);
////         Object usuarios = null;
//        jFmtCpf.setEnabled(false);
//        jFmtDataNascimento.setEnabled(false);
//        jPwdSenha.setEnabled(false);
//        jChbAtivo.setEnabled(false);
//        jCboNivel.setEnabled(false);
//        jTxtNome.setEnabled(false);
//        jTxtApelido.setEnabled(false);
//        jTxtIdUsuario.setEnabled(false);
//        jBtnAlterar.setEnabled(false);
//        jBtnCancelar.setEnabled(false);
//        jBtnConfirmar.setEnabled(false);
//        jBtnExcluir.setEnabled(false);
//        jBtnIncluir.setEnabled(false);
//        jBtnPesquisar.setEnabled(false);
//
//        habilitar(true, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar);
    }

    void habilitar(boolean valor, JComponent... componentes) {
        for (int i = 0; i < componentes.length; i++) {
            JComponent componente = componentes[i];
            componente.setEnabled(valor);
        }
    }
//    void habilitar(boolean valor) {
//        Util.habilitar(valor, componentes);
//        Util.habilitar(!valor, componentes);
//    }

    void limpar() {
        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jBtnCancelar, jBtnConfirmar);
    }

//    void desabilitar(JComponent... componentes) {
//
//        for (int i = 0; i < componentes.length; i++) {
//            JComponent componente = componentes[i];
//            componente.setEnabled(false);
//
//        }
//    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTxtApelido = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTxtIdUsuario = new javax.swing.JTextField();
        jChbAtivo = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jPwdSenha = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        jBtnIncluir = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnPesquisar = new javax.swing.JButton();
        jFmtCpf = new javax.swing.JFormattedTextField();
        jFmtDataNascimento = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        jCboNivel = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Cadastro de Usuário");

        jLabel2.setText("CPF");

        jLabel3.setText("Nome");

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });

        jLabel5.setText("Apelido");

        jTxtApelido.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtApelidoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtApelidoFocusLost(evt);
            }
        });

        jLabel6.setText("Senha");

        jLabel4.setText("Código");

        jTxtIdUsuario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtIdUsuarioFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtIdUsuarioFocusLost(evt);
            }
        });

        jChbAtivo.setText("Ativo");

        jLabel9.setText("Data de Nascimento");

        jPwdSenha.setText("jPasswordField1");
        jPwdSenha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jPwdSenhaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jPwdSenhaFocusLost(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnIncluir);

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnExcluir);

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnCancelar);

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnConfirmar);

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnAlterar);

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(jBtnPesquisar);

        try {
            jFmtCpf.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jFmtCpf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusLost(evt);
            }
        });

        jFmtDataNascimento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter(new java.text.SimpleDateFormat(""))));
        jFmtDataNascimento.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtDataNascimentoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtDataNascimentoFocusLost(evt);
            }
        });

        jLabel7.setText("Nível");

        jCboNivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrador", "Cliente", "Funcionário" }));
        jCboNivel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jCboNivelFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jCboNivelFocusLost(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(211, 211, 211)
                                .addComponent(jLabel9))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5))
                                .addGap(82, 82, 82)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel6)
                                            .addComponent(jTxtIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jPwdSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(71, 71, 71)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jChbAtivo)
                                            .addComponent(jLabel7)
                                            .addComponent(jCboNivel, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(93, 93, 93)
                                .addComponent(jLabel8))
                            .addComponent(jTxtApelido, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(89, 89, 89)
                                .addComponent(jFmtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(203, 203, 203)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel3))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jFmtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addComponent(jLabel4)
                        .addGap(16, 16, 16))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtApelido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtIdUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel2)
                        .addGap(26, 26, 26))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jCboNivel))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(jLabel6)))
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jChbAtivo)
                            .addComponent(jPwdSenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)))
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jLabel8))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
        if (Util.perguntar("Deseja excluir o registro?") == true) {
        } else {
            Util.mensagem("Exclusão cancelada");
        }
        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo);
    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
        // TODO add your handling code here:
        //desabilitar();
//        Util.habilitar(false, jBtnAlterar, jBtnExcluir, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
//        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha);
        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo);
        habilitar(false, jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        //desabilitar();
//        Util.habilitar(false, jBtnAlterar, jBtnExcluir, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
//        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha);
//        incluindo = false;
        if (incluindo == true) {
        } else {
        }
        habilitar(false, jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo);
    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
//        //habilitar(true, );
//        //habilitar(true, incluir, alterar, excluir);
//        incluindo = true;
        habilitar(true, jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo, jBtnCancelar, jBtnConfirmar);
//     incluindo = true;
        habilitar(false, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        incluindo = true;
//        habilitar(true);
        Util.limpar(jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jChbAtivo);
    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        Object usuarios = null;
        if (usuarios != null) {
            incluindo = false;
            habilitar(true, jTxtApelido, jTxtIdUsuario, jTxtNome, jCboNivel, jFmtCpf, jFmtDataNascimento, jPwdSenha, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar, jChbAtivo, jBtnCancelar, jBtnConfirmar);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum produto está disponível para alteração.");
        }
        // habilitar();
    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        JDlgUsuariosPesquisa jDlgPesquisaUsuario = new JDlgUsuariosPesquisa(null, true);
        jDlgPesquisaUsuario.setVisible(true);
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jTxtApelidoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtApelidoFocusGained
        // TODO add your handling code here:
        jTxtApelido.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtApelidoFocusGained

    private void jTxtApelidoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtApelidoFocusLost
        // TODO add your handling code here:
        jTxtApelido.setBackground(Color.white);
    }//GEN-LAST:event_jTxtApelidoFocusLost

    private void jFmtCpfFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusGained
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtCpfFocusGained

    private void jFmtCpfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusLost
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.white);
    }//GEN-LAST:event_jFmtCpfFocusLost

    private void jFmtDataNascimentoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtDataNascimentoFocusGained
        // TODO add your handling code here:
        jFmtDataNascimento.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtDataNascimentoFocusGained

    private void jFmtDataNascimentoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtDataNascimentoFocusLost
        // TODO add your handling code here:
        jFmtDataNascimento.setBackground(Color.white);
    }//GEN-LAST:event_jFmtDataNascimentoFocusLost

    private void jTxtIdUsuarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdUsuarioFocusGained
        // TODO add your handling code here:
        jTxtIdUsuario.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtIdUsuarioFocusGained

    private void jTxtIdUsuarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtIdUsuarioFocusLost
        // TODO add your handling code here:
        jTxtIdUsuario.setBackground(Color.white);
    }//GEN-LAST:event_jTxtIdUsuarioFocusLost

    private void jPwdSenhaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPwdSenhaFocusGained
        // TODO add your handling code here:
        jPwdSenha.setBackground(Color.pink);
    }//GEN-LAST:event_jPwdSenhaFocusGained

    private void jPwdSenhaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jPwdSenhaFocusLost
        // TODO add your handling code here:
        jPwdSenha.setBackground(Color.white);
    }//GEN-LAST:event_jPwdSenhaFocusLost

    private void jCboNivelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jCboNivelFocusGained
        // TODO add your handling code here:
        jCboNivel.setBackground(Color.pink);
    }//GEN-LAST:event_jCboNivelFocusGained

    private void jCboNivelFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jCboNivelFocusLost
        // TODO add your handling code here:
        jCboNivel.setBackground(Color.white);
    }//GEN-LAST:event_jCboNivelFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgUsuarios dialog = new JDlgUsuarios(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JComboBox<String> jCboNivel;
    private javax.swing.JCheckBox jChbAtivo;
    private javax.swing.JFormattedTextField jFmtCpf;
    private javax.swing.JFormattedTextField jFmtDataNascimento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPwdSenha;
    private javax.swing.JTextField jTxtApelido;
    private javax.swing.JTextField jTxtIdUsuario;
    private javax.swing.JTextField jTxtNome;
    // End of variables declaration//GEN-END:variables

}
