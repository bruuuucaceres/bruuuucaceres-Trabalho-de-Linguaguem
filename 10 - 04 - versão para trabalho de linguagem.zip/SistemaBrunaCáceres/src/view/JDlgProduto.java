package view;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import tools.Util;

public class JDlgProduto extends javax.swing.JDialog {

    boolean incluindo;

    public JDlgProduto(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTitle("Cadastro do Produto");
        setLocationRelativeTo(null);
        Util.habilitar(false, jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto, jBtnCancelar, jBtnConfirmar);
//        jBtnAlterar.setEnabled(false);
//        jBtnCancelar.setEnabled(false);
//        jBtnConfirmar.setEnabled(false);
//        jBtnExcluir.setEnabled(false);
//        jBtnIncluir.setEnabled(false);
//        jBtnPesquisar.setEnabled(false);
//        jTxtCategoria.setEnabled(false);
//        jTxtEstoque.setEnabled(false);
//        jTxtNome.setEnabled(false);
//        jTxtQuantidade.setEnabled(false);
//        jTxtValor.setEnabled(false);
//        jTxtidProduto.setEnabled(false);
//
//        habilitar(true, jBtnIncluir,  jBtnAlterar,jBtnExcluir, jBtnPesquisar);
    }

    void habilitar(boolean valor, JComponent... componentes) {
        for (int i = 0; i < componentes.length; i++) {
            JComponent componente = componentes[i];
            componente.setEnabled(valor);
        }
    }

//    void desabilitar(JComponent... componentes) {
//
//        for (int i = 0; i < componentes.length; i++) {
//            JComponent componente = componentes[i];
//            componente.setEnabled(false);
//
//        }
//    }
    void limpar() {
        Util.limpar(jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto, jBtnCancelar, jBtnConfirmar);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtCategoria = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTxtEstoque = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTxtValor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTxtQuantidade = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTxtidProduto = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jBtnPesquisar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnIncluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTxtCategoria.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtCategoriaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtCategoriaFocusLost(evt);
            }
        });

        jLabel1.setText("Nome");

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });

        jLabel2.setText("Estoque");

        jTxtEstoque.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEstoqueFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEstoqueFocusLost(evt);
            }
        });

        jLabel3.setText("Valor");

        jTxtValor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtValorFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtValorFocusLost(evt);
            }
        });

        jLabel4.setText("Quantidade");

        jTxtQuantidade.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtQuantidadeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtQuantidadeFocusLost(evt);
            }
        });

        jLabel5.setText("Categoria");

        jLabel6.setText("Código");

        jTxtidProduto.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtidProdutoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtidProdutoFocusLost(evt);
            }
        });

        jLabel7.setText("Tela de Produtos");

        jPanel1.setBackground(new java.awt.Color(255, 153, 255));

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtnIncluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnAlterar)
                .addGap(18, 18, 18)
                .addComponent(jBtnExcluir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBtnConfirmar)
                .addGap(10, 10, 10)
                .addComponent(jBtnPesquisar))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jBtnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jBtnPesquisar)
                            .addComponent(jBtnCancelar)
                            .addComponent(jBtnExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jBtnAlterar)
                            .addComponent(jBtnIncluir))
                        .addGap(10, 10, 10))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2)
                            .addComponent(jTxtEstoque, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(jTxtNome, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel6)
                            .addComponent(jTxtidProduto))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(71, 71, 71)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTxtValor, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(jLabel5))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jLabel4))
                                    .addComponent(jTxtCategoria)
                                    .addComponent(jTxtQuantidade)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(83, 83, 83)
                                .addComponent(jLabel3)))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(188, 188, 188)
                .addComponent(jLabel7)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jLabel6)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtidProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtQuantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel5))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
        // TODO add your handling code here:
//        jBtnAlterar.setEnabled(true);
//        jBtnCancelar.setEnabled(true);
//        jBtnConfirmar.setEnabled(true);
//        jBtnExcluir.setEnabled(true);
//        jBtnIncluir.setEnabled(true);
//        jBtnPesquisar.setEnabled(true);
//        jTxtCategoria.setEnabled(true);
//        jTxtEstoque.setEnabled(true);
//        jTxtNome.setEnabled(true);
//        jTxtQuantidade.setEnabled(true);
//        jTxtValor.setEnabled(true);
//        jTxtidProduto.setEnabled(true);
        //        //habilitar(true, );
//        //habilitar(true, incluir, alterar, excluir);
//        incluindo = true;
        habilitar(true, jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto, jBtnCancelar, jBtnConfirmar);
//     incluindo = true;
        habilitar(false, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        incluindo = true;
//        habilitar(true);
        Util.limpar(jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto);

    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        // TODO add your handling code here:
        Object usuarios = null;
        if (usuarios != null) {
            incluindo = false;
            habilitar(true, jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar, jBtnCancelar, jBtnConfirmar);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum produto está disponível para alteração.");
        }
        // habilitar();

    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
        if (Util.perguntar("Deseja excluir o registro?") == true) {
        } else {
            Util.mensagem("Exclusão cancelada");
        }
        Util.limpar(jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto);

    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
        // TODO add your handling code here:
        Util.limpar(jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto);
        habilitar(false, jTxtCategoria, jTxtidProduto, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);

    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        // TODO add your handling code here:
        if (incluindo == true) {
        } else {
        }
        Util.limpar(jTxtCategoria, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jTxtidProduto);
        habilitar(false, jTxtCategoria, jTxtidProduto, jTxtEstoque, jTxtNome, jTxtQuantidade, jTxtValor, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);

    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        // TODO add your handling code here:
        JDlgProdutoPesquisa jDlgProdutoPesquisa = new JDlgProdutoPesquisa(null, true);
        jDlgProdutoPesquisa.setVisible(true);
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jTxtidProdutoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtidProdutoFocusGained
        // TODO add your handling code here:
        jTxtidProduto.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtidProdutoFocusGained

    private void jTxtidProdutoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtidProdutoFocusLost
        // TODO add your handling code here:
        jTxtidProduto.setBackground(Color.white);
    }//GEN-LAST:event_jTxtidProdutoFocusLost

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jTxtEstoqueFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstoqueFocusGained
        // TODO add your handling code here:
        jTxtEstoque.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEstoqueFocusGained

    private void jTxtEstoqueFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEstoqueFocusLost
        // TODO add your handling code here:
        jTxtEstoque.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEstoqueFocusLost

    private void jTxtQuantidadeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtQuantidadeFocusGained
        // TODO add your handling code here:
        jTxtQuantidade.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtQuantidadeFocusGained

    private void jTxtQuantidadeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtQuantidadeFocusLost
        // TODO add your handling code here:
        jTxtQuantidade.setBackground(Color.white);
    }//GEN-LAST:event_jTxtQuantidadeFocusLost

    private void jTxtCategoriaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCategoriaFocusGained
        // TODO add your handling code here:
        jTxtCategoria.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtCategoriaFocusGained

    private void jTxtCategoriaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtCategoriaFocusLost
        // TODO add your handling code here:
        jTxtCategoria.setBackground(Color.white);
    }//GEN-LAST:event_jTxtCategoriaFocusLost

    private void jTxtValorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtValorFocusGained
        // TODO add your handling code here:
        jTxtValor.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtValorFocusGained

    private void jTxtValorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtValorFocusLost
        // TODO add your handling code here:
        jTxtValor.setBackground(Color.white);
    }//GEN-LAST:event_jTxtValorFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgProduto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgProduto dialog = new JDlgProduto(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTxtCategoria;
    private javax.swing.JTextField jTxtEstoque;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtQuantidade;
    private javax.swing.JTextField jTxtValor;
    private javax.swing.JTextField jTxtidProduto;
    // End of variables declaration//GEN-END:variables
}
