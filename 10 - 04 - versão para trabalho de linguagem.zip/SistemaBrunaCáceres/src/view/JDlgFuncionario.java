package view;

import java.awt.Color;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import tools.Util;

public class JDlgFuncionario extends javax.swing.JDialog {

    boolean incluindo;
    private MaskFormatter mascaraCPF;
    private MaskFormatter mascaraDataDeNascimento;

    public JDlgFuncionario(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTitle("Cadastro do Funcionário");
        setLocationRelativeTo(null);
        Util.habilitar(false, jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnCancelar, jBtnConfirmar);
        try {
            mascaraCPF = new MaskFormatter("###.###.###-##");
        } catch (Exception e) {
            System.err.println("Erro na máscara");
        }
        jFmtCpf.setFormatterFactory(new DefaultFormatterFactory(mascaraCPF));
//        jBtnAlterar.setEnabled(false);
//        jBtnCancelar.setEnabled(false);
//        jBtnConfirmar.setEnabled(false);
//        jBtnExcluir.setEnabled(false);
//        jBtnIncluir.setEnabled(false);
//        jBtnPesquisar.setEnabled(false);
//        jFmtCpf.setEnabled(false);
//        jTxtEndereco.setEnabled(false);
//        jTxtNome.setEnabled(false);
//        jTxtTelefone.setEnabled(false);
//        jTxtidFuncionario.setEnabled(false);

//        habilitar(true, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar);
    }

    void habilitar(boolean valor, JComponent... componentes) {
        for (int i = 0; i < componentes.length; i++) {
            JComponent componente = componentes[i];
            componente.setEnabled(valor);
        }
    }

//    void desabilitar(JComponent... componentes) {
//
//        for (int i = 0; i < componentes.length; i++) {
//            JComponent componente = componentes[i];
//            componente.setEnabled(false);
//
//        }
//    }
    void limpar() {
        Util.limpar(jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnCancelar, jBtnConfirmar);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTxtNome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTxtTelefone = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTxtEndereco = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTxtidFuncionario = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jFmtCpf = new javax.swing.JFormattedTextField();
        jPanel1 = new javax.swing.JPanel();
        jBtnPesquisar = new javax.swing.JButton();
        jBtnConfirmar = new javax.swing.JButton();
        jBtnCancelar = new javax.swing.JButton();
        jBtnExcluir = new javax.swing.JButton();
        jBtnAlterar = new javax.swing.JButton();
        jBtnIncluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("                      Cadastro de Funcionário");

        jLabel2.setText("Nome");

        jTxtNome.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtNomeFocusLost(evt);
            }
        });

        jLabel3.setText("Telefone");

        jTxtTelefone.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtTelefoneFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtTelefoneFocusLost(evt);
            }
        });

        jLabel5.setText("CPF");

        jLabel6.setText("Endereço");

        jTxtEndereco.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtEnderecoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtEnderecoFocusLost(evt);
            }
        });

        jTxtidFuncionario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTxtidFuncionarioFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTxtidFuncionarioFocusLost(evt);
            }
        });

        jLabel9.setText("Código");

        jFmtCpf.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFmtCpfFocusLost(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 153, 255));

        jBtnPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pesquisar.png"))); // NOI18N
        jBtnPesquisar.setText("Pesquisar");
        jBtnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnPesquisarActionPerformed(evt);
            }
        });

        jBtnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/confirmar.png"))); // NOI18N
        jBtnConfirmar.setText("Confirmar");
        jBtnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnConfirmarActionPerformed(evt);
            }
        });

        jBtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cancelar.png"))); // NOI18N
        jBtnCancelar.setText("Cancelar");
        jBtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnCancelarActionPerformed(evt);
            }
        });

        jBtnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Excluir.png"))); // NOI18N
        jBtnExcluir.setText("Excluir");
        jBtnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnExcluirActionPerformed(evt);
            }
        });

        jBtnAlterar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/alterar.png"))); // NOI18N
        jBtnAlterar.setText("Alterar");
        jBtnAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAlterarActionPerformed(evt);
            }
        });

        jBtnIncluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/incluir.png"))); // NOI18N
        jBtnIncluir.setText("Incluir");
        jBtnIncluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnIncluirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jBtnIncluir)
                .addGap(18, 18, 18)
                .addComponent(jBtnAlterar)
                .addGap(18, 18, 18)
                .addComponent(jBtnExcluir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtnCancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jBtnConfirmar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBtnPesquisar)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnPesquisar)
                    .addComponent(jBtnConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jBtnCancelar)
                    .addComponent(jBtnExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jBtnAlterar)
                    .addComponent(jBtnIncluir)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTxtTelefone)
                                    .addComponent(jLabel9)
                                    .addComponent(jTxtidFuncionario, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                                    .addComponent(jLabel3))
                                .addGap(142, 142, 142)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(jTxtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel9))
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtidFuncionario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel8)
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTxtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTxtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jFmtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnIncluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnIncluirActionPerformed
//        jBtnAlterar.setEnabled(true);
//        jBtnCancelar.setEnabled(true);
//        jBtnConfirmar.setEnabled(true);
//        jBtnExcluir.setEnabled(true);
//        jBtnIncluir.setEnabled(true);
//        jBtnPesquisar.setEnabled(true);
//        jFmtCpf.setEnabled(true);
//        jTxtEndereco.setEnabled(true);
//        jTxtNome.setEnabled(true);
//        jTxtTelefone.setEnabled(true);
//        jTxtidFuncionario.setEnabled(true);
        habilitar(false, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);
        habilitar(true, jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnCancelar, jBtnConfirmar);
//     incluindo = true;

        incluindo = true;
//        habilitar(true);
        Util.limpar(jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf);

    }//GEN-LAST:event_jBtnIncluirActionPerformed

    private void jBtnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAlterarActionPerformed
        Object usuarios = null;
        if (usuarios != null) {
            incluindo = false;
            habilitar(true, jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnPesquisar, jBtnCancelar, jBtnConfirmar);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum produto está disponível para alteração.");
        }
        // habilitar();

    }//GEN-LAST:event_jBtnAlterarActionPerformed

    private void jBtnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnExcluirActionPerformed
        if (Util.perguntar("Deseja excluir o registro?") == true) {
        } else {
            Util.mensagem("Exclusão cancelada");
        }
        Util.limpar(jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf);
    }//GEN-LAST:event_jBtnExcluirActionPerformed

    private void jBtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnCancelarActionPerformed
        Util.limpar(jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf);
        habilitar(false, jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);

    }//GEN-LAST:event_jBtnCancelarActionPerformed

    private void jBtnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnConfirmarActionPerformed
        if (incluindo == true) {
        } else {
        }
        Util.limpar(jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf);
        habilitar(false, jTxtEndereco, jTxtNome, jTxtTelefone, jTxtidFuncionario, jFmtCpf, jBtnCancelar, jBtnConfirmar);
        habilitar(true, jBtnIncluir, jBtnAlterar, jBtnExcluir, jBtnIncluir, jBtnPesquisar);

    }//GEN-LAST:event_jBtnConfirmarActionPerformed

    private void jBtnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnPesquisarActionPerformed
        JDlgFuncionarioPesquisa jDlgFuncionarioPesquisa = new JDlgFuncionarioPesquisa(null, true);
        jDlgFuncionarioPesquisa.setVisible(true);
//        maiúsculo: classe
//        minúsculo : atributo
    }//GEN-LAST:event_jBtnPesquisarActionPerformed

    private void jTxtidFuncionarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtidFuncionarioFocusGained
        // TODO add your handling code here:
        jTxtidFuncionario.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtidFuncionarioFocusGained

    private void jTxtidFuncionarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtidFuncionarioFocusLost
        // TODO add your handling code here:
        jTxtidFuncionario.setBackground(Color.white);
    }//GEN-LAST:event_jTxtidFuncionarioFocusLost

    private void jTxtTelefoneFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneFocusLost
        // TODO add your handling code here:
        jTxtTelefone.setBackground(Color.white);
    }//GEN-LAST:event_jTxtTelefoneFocusLost

    private void jTxtTelefoneFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtTelefoneFocusGained
        // TODO add your handling code here:
        jTxtTelefone.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtTelefoneFocusGained

    private void jFmtCpfFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusGained
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.pink);
    }//GEN-LAST:event_jFmtCpfFocusGained

    private void jFmtCpfFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFmtCpfFocusLost
        // TODO add your handling code here:
        jFmtCpf.setBackground(Color.white);
    }//GEN-LAST:event_jFmtCpfFocusLost

    private void jTxtNomeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusGained
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtNomeFocusGained

    private void jTxtNomeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtNomeFocusLost
        // TODO add your handling code here:
        jTxtNome.setBackground(Color.white);
    }//GEN-LAST:event_jTxtNomeFocusLost

    private void jTxtEnderecoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEnderecoFocusGained
        // TODO add your handling code here:
        jTxtEndereco.setBackground(Color.pink);
    }//GEN-LAST:event_jTxtEnderecoFocusGained

    private void jTxtEnderecoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTxtEnderecoFocusLost
        // TODO add your handling code here:
        jTxtEndereco.setBackground(Color.white);
    }//GEN-LAST:event_jTxtEnderecoFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JDlgFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JDlgFuncionario dialog = new JDlgFuncionario(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAlterar;
    private javax.swing.JButton jBtnCancelar;
    private javax.swing.JButton jBtnConfirmar;
    private javax.swing.JButton jBtnExcluir;
    private javax.swing.JButton jBtnIncluir;
    private javax.swing.JButton jBtnPesquisar;
    private javax.swing.JFormattedTextField jFmtCpf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTxtEndereco;
    private javax.swing.JTextField jTxtNome;
    private javax.swing.JTextField jTxtTelefone;
    private javax.swing.JTextField jTxtidFuncionario;
    // End of variables declaration//GEN-END:variables
}
