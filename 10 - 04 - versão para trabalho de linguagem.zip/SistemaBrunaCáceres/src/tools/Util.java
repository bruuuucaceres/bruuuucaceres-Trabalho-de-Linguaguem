package tools;
//classe stática que dá pra chamar nas telas e usar sem precisar fazer muito código
//pra n criar objeto é usado o static, método sem instanciar classe, posso usar ele direto
//cancelar e confirmar deve desabilitar e deixar a tela como no iniciar

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Util {

    public static void mensagem(String msg) {
        JOptionPane.showMessageDialog(null, msg);

    }

    public static boolean perguntar(String msg) {
        int resp = JOptionPane.showConfirmDialog(null, msg,
                "Pergunta", JOptionPane.YES_NO_OPTION); //YES_NO_OPTION é uma constante 
        return resp == JOptionPane.YES_NO_OPTION; //se não for true fai ser falso
    }

//    public static void habilitar(String msg) {
//        //void= não tem retorno
//        
//    }
    public static void habilitar(boolean valor, JComponent... componentes) {
        for (int i = 0; i < componentes.length; i++) {
            JComponent componente = componentes[i];
            componente.setEnabled(valor);
        }
    }

    public static void limpar(JComponent... component) { // varargs //tira o conteúdo dos campos, esvazia //se faz pra ser aceito, vira jcomponent 
        //como eu sei quem era?
        //incluir limpa 
        //confirmar limpa
        //alterar não limpa
        //excluir limpa
        //cancelar limpa
        for (int i = 0; i < component.length; i++) {
            //JComponent componente = componentes [i];
            //componente.setEnabled(valor); enable habilita e desabilita
            if (component[i] instanceof JTextField) { //será que le foi um texfield??? essa é a pergunta //instance off verifica quem voce era
                ((JTextField) component[i]).setText("");
            }
            if (component[i] instanceof JComboBox) { //será que le foi um JComboBox??? essa é a pergunta
                ((JComboBox) component[i]).setSelectedIndex(-1); //se colocar um ele não seleciona nenhum
                //
            }
            if (component[i] instanceof JCheckBox) { //será que le foi um JCheckBox??? essa é a pergunta
                ((JCheckBox) component[i]).setSelected(true);
            }
        }
    }

}
